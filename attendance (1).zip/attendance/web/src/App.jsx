import { useState } from 'react';
import LiveRoster from './LiveRoster.jsx';
import QRDisplay from './QRDisplay.jsx';
import StudentScanner from './StudentScanner.jsx';

const SESSION_ID = Number(import.meta.env.VITE_SESSION_ID || 1);

// DEV login switcher: the backend currently trusts these ids via headers.
// Replace with real login before any real use.
const USERS = [
  { key: 'teacher', label: 'Teacher', role: 'teacher', id: 1 },
  ...[1, 2, 3, 4, 5].map((n) => ({ key: `s${n}`, label: `Student ${n}`, role: 'student', id: n })),
];

const TEACHER_TABS = [
  { key: 'roster', label: 'Live Roster' },
  { key: 'qr', label: 'QR Code' },
  { key: 'analytics', label: 'Analytics' },
  { key: 'leave', label: 'Leave Requests' },
];

function ComingSoon({ title }) {
  return (
    <div className="p-10 text-center text-gray-500">
      <p className="font-medium">{title}</p>
      <p className="mt-1 text-sm">Not built yet. This tab is next on the list.</p>
    </div>
  );
}

export default function App() {
  const [userKey, setUserKey] = useState('teacher');
  const [tab, setTab] = useState('roster');
  const user = USERS.find((u) => u.key === userKey);

  return (
    <div className="mx-auto max-w-3xl">
      <header className="flex items-center justify-between border-b bg-white px-4 py-3">
        <h1 className="text-lg font-bold">College Attendance</h1>
        <label className="text-sm text-gray-600">
          Dev login:{' '}
          <select
            className="rounded border px-2 py-1"
            value={userKey}
            onChange={(e) => { setUserKey(e.target.value); setTab('roster'); }}
          >
            {USERS.map((u) => <option key={u.key} value={u.key}>{u.label}</option>)}
          </select>
        </label>
      </header>

      {user.role === 'teacher' ? (
        <>
          <nav className="flex border-b bg-white">
            {TEACHER_TABS.map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex-1 px-3 py-3 text-sm font-medium ${
                  tab === t.key ? 'border-b-2 border-green-600 text-green-700' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </nav>
          <main className="bg-white">
            {tab === 'roster' && <LiveRoster sessionId={SESSION_ID} teacherId={user.id} />}
            {tab === 'qr' && <QRDisplay sessionId={SESSION_ID} teacherId={user.id} />}
            {tab === 'analytics' && <ComingSoon title="Analytics & Low Attendance Warnings" />}
            {tab === 'leave' && <ComingSoon title="Leave Request Approvals" />}
          </main>
        </>
      ) : (
        <main className="bg-white">
          <StudentScanner key={user.key} studentId={user.id} />
        </main>
      )}
    </div>
  );
}
