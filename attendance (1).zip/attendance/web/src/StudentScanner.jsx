// npm i html5-qrcode
import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';

const API = import.meta.env.VITE_API_URL ?? '';

// Resolves with { lat, lng } or rejects with a readable error
function getPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('Location not supported'));
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => reject(new Error('Please allow location access to mark attendance')),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  });
}

export default function StudentScanner({ studentId }) {
  const scannerRef = useRef(null);
  const busyRef = useRef(false);
  const [msg, setMsg] = useState({ type: 'info', text: 'Point your camera at the classroom QR code' });

  useEffect(() => {
    const scanner = new Html5Qrcode('qr-reader');
    scannerRef.current = scanner;

    scanner
      .start(
        { facingMode: 'environment' }, // rear camera
        { fps: 10, qrbox: { width: 250, height: 250 } },
        async (decodedText) => {
          if (busyRef.current) return; // ignore repeat decodes while submitting
          busyRef.current = true;
          try {
            setMsg({ type: 'info', text: 'Checking location…' });
            const { lat, lng } = await getPosition();
            const res = await fetch(`${API}/api/attendance/scan`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'x-user-id': studentId, 'x-role': 'student' },
              body: JSON.stringify({ token: decodedText, lat, lng }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Scan failed');
            setMsg({ type: 'success', text: '✅ Marked present!' });
            await scanner.stop(); // done, release the camera
          } catch (e) {
            setMsg({ type: 'error', text: e.message });
            setTimeout(() => { busyRef.current = false; }, 2000); // allow retry
          }
        },
        () => {} // per-frame "no QR found" noise
      )
      .catch(() => setMsg({ type: 'error', text: 'Camera unavailable. Check browser permissions.' }));

    return () => {
      scanner.isScanning && scanner.stop().catch(() => {});
    };
  }, [studentId]);

  const color = { info: 'text-gray-700', success: 'text-green-600', error: 'text-red-600' }[msg.type];

  return (
    <div className="mx-auto max-w-sm p-4">
      <div id="qr-reader" className="overflow-hidden rounded-xl" />
      <p className={`mt-4 text-center font-medium ${color}`}>{msg.text}</p>
    </div>
  );
}
