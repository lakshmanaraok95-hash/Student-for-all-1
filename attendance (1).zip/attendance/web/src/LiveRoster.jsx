// npm i socket.io-client
import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

const API = import.meta.env.VITE_API_URL ?? '';
const headers = (teacherId) => ({
  'Content-Type': 'application/json',
  'x-user-id': teacherId,
  'x-role': 'teacher',
});

export default function LiveRoster({ sessionId, teacherId }) {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState('');

  // Initial load
  useEffect(() => {
    fetch(`${API}/api/sessions/${sessionId}/roster`, { headers: headers(teacherId) })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error('Could not load roster'))))
      .then(setStudents)
      .catch((e) => setError(e.message));
  }, [sessionId, teacherId]);

  // Live updates: a QR scan elsewhere flips a row here instantly
  useEffect(() => {
    const socket = io(API);
    socket.emit('join', sessionId);
    socket.on('attendance', ({ studentId, status, method }) => {
      setStudents((prev) => prev.map((s) => (s.id === studentId ? { ...s, status, method } : s)));
    });
    return () => socket.disconnect();
  }, [sessionId]);

  // Manual override: update the UI at once, roll back if the save fails
  async function toggle(student) {
    const next = student.status === 'PRESENT' ? 'ABSENT' : 'PRESENT';
    const before = students;
    setStudents((prev) =>
      prev.map((s) => (s.id === student.id ? { ...s, status: next, method: 'MANUAL_OVERRIDE' } : s))
    );
    try {
      const res = await fetch(`${API}/api/sessions/${sessionId}/attendance/${student.id}`, {
        method: 'PUT',
        headers: headers(teacherId),
        body: JSON.stringify({ status: next }),
      });
      if (!res.ok) throw new Error();
    } catch {
      setStudents(before);
      setError('Save failed, change reverted');
    }
  }

  const present = students.filter((s) => s.status === 'PRESENT').length;

  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Live Attendance</h2>
        <span className="text-sm text-gray-600">{present} / {students.length} present</span>
      </div>
      {error && <p className="mb-2 text-sm text-red-600">{error}</p>}
      <ul className="divide-y rounded-lg border">
        {students.map((s) => (
          <li key={s.id} className="flex items-center justify-between px-4 py-3">
            <div>
              <p className="font-medium">{s.name}</p>
              <p className="text-xs text-gray-500">
                {s.roll_no}
                {s.method && ` · ${s.method === 'QR' ? 'QR scan' : 'Manual'}`}
              </p>
            </div>
            <input
              type="checkbox"
              className="h-5 w-5 accent-green-600"
              checked={s.status === 'PRESENT'}
              onChange={() => toggle(s)}
            />
          </li>
        ))}
      </ul>
    </div>
  );
}
