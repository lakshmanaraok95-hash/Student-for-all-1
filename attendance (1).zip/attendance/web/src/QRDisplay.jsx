import { useEffect, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';

const API = import.meta.env.VITE_API_URL ?? '';

// Shown on the classroom projector. Fetches a fresh token whenever the old one expires.
export default function QRDisplay({ sessionId, teacherId }) {
  const [token, setToken] = useState('');
  const [msLeft, setMsLeft] = useState(0);
  const [error, setError] = useState('');
  const expiresAt = useRef(0);

  useEffect(() => {
    let cancelled = false;
    let timer;

    async function load() {
      try {
        const res = await fetch(`${API}/api/sessions/${sessionId}/qr`, {
          headers: { 'x-user-id': teacherId, 'x-role': 'teacher' },
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Could not load QR');
        if (cancelled) return;
        setToken(data.token);
        setError('');
        expiresAt.current = Date.now() + data.expiresInMs;
        // refresh just after the window rolls over
        timer = setTimeout(load, data.expiresInMs + 150);
      } catch (e) {
        if (cancelled) return;
        setError(e.message);
        timer = setTimeout(load, 3000); // retry
      }
    }
    load();

    const tick = setInterval(() => setMsLeft(Math.max(0, expiresAt.current - Date.now())), 200);
    return () => {
      cancelled = true;
      clearTimeout(timer);
      clearInterval(tick);
    };
  }, [sessionId, teacherId]);

  const pct = Math.min(100, (msLeft / 15000) * 100);

  return (
    <div className="flex flex-col items-center p-6">
      <h2 className="mb-1 text-lg font-semibold">Scan to mark attendance</h2>
      <p className="mb-4 text-sm text-gray-500">This code changes every 15 seconds</p>
      {error ? (
        <p className="text-red-600">{error}</p>
      ) : token ? (
        <div className="rounded-2xl border bg-white p-4 shadow">
          <QRCodeSVG value={token} size={288} level="M" />
        </div>
      ) : (
        <p className="text-gray-500">Loading…</p>
      )}
      <div className="mt-4 h-2 w-72 overflow-hidden rounded bg-gray-200">
        <div className="h-full bg-green-600 transition-all duration-200" style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-1 text-xs text-gray-500">{Math.ceil(msLeft / 1000)}s left</p>
    </div>
  );
}
