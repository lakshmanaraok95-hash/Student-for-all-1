// DEV ONLY: wipes the database and loads test data.
// Usage: npm run seed   (requires the --reset flag, already in the npm script)
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Pool } = require('pg');

(async () => {
  if (!process.argv.includes('--reset')) {
    console.error('Refusing to run: this DROPS all tables. Re-run with --reset.');
    process.exit(1);
  }
  const lat = parseFloat(process.env.ROOM_LAT);
  const lng = parseFloat(process.env.ROOM_LNG);
  if (Number.isNaN(lat) || Number.isNaN(lng)) {
    console.error('Set ROOM_LAT and ROOM_LNG in .env first (the geofence needs a classroom location).');
    process.exit(1);
  }
  const radius = parseInt(process.env.ROOM_RADIUS || '100', 10);

  const db = new Pool({ connectionString: process.env.DATABASE_URL });
  try {
    await db.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
    await db.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

    const names = ['Asha Reddy', 'Ravi Kumar', 'Meena Iyer', 'Imran Khan', 'Sneha Rao'];
    for (let i = 0; i < names.length; i++) {
      await db.query('INSERT INTO students (roll_no, name, email) VALUES ($1,$2,$3)',
        [`CS2026${String(i + 1).padStart(2, '0')}`, names[i], `student${i + 1}@example.edu`]);
    }

    // teacher_id 1 is just a number; the stub auth uses it as the teacher's id
    await db.query("INSERT INTO courses (code, title, teacher_id) VALUES ('CS101','Intro to Programming',1)");
    for (let sid = 1; sid <= names.length; sid++)
      await db.query('INSERT INTO enrollments (student_id, course_id) VALUES ($1,1)', [sid]);

    await db.query(
      `INSERT INTO class_sessions (course_id, starts_at, ends_at, room_lat, room_lng, radius_m, qr_secret)
       VALUES (1, now(), now() + interval '2 hours', $1, $2, $3, $4)`,
      [lat, lng, radius, crypto.randomBytes(32).toString('hex')]);

    console.log('Seeded: 5 students (ids 1-5), 1 teacher (id 1), course CS101, session id 1 (open for 2 hours).');
  } catch (e) {
    console.error('Seed failed:', e.message);
    process.exit(1);
  } finally {
    await db.end();
  }
})();
