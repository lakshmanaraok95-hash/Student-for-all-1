require('dotenv').config();
// npm i express pg socket.io
const express = require('express');
const http = require('http');
const crypto = require('crypto');
const { Pool } = require('pg');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.WEB_ORIGIN || 'http://localhost:5173' } });

// Minimal CORS for the Vite dev server (swap for the `cors` package if you prefer)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', process.env.WEB_ORIGIN || 'http://localhost:5173');
  res.header('Access-Control-Allow-Headers', 'Content-Type, x-user-id, x-role');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json());

// Teachers' dashboards join a room per session to receive live updates
io.on('connection', (socket) => {
  socket.on('join', (sessionId) => socket.join(`session:${sessionId}`));
});
const db = new Pool({ connectionString: process.env.DATABASE_URL });

const WINDOW_MS = 15_000; // token lifetime

// TODO: replace with real auth (JWT/session) that sets req.user = { id, role }
function auth(req, _res, next) {
  req.user = { id: Number(req.header('x-user-id')), role: req.header('x-role') };
  next();
}
app.use(auth);

// ---- token helpers ---------------------------------------------------------
function tokenFor(sessionId, secret, windowIdx) {
  const sig = crypto
    .createHmac('sha256', secret)
    .update(`${sessionId}:${windowIdx}`)
    .digest('hex')
    .slice(0, 16);
  return `${sessionId}.${windowIdx}.${sig}`;
}

function haversineMeters(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// ---- teacher: current QR token (the classroom screen polls this every ~5s) --
app.get('/api/sessions/:id/qr', async (req, res) => {
  if (req.user.role !== 'teacher') return res.sendStatus(403);
  const { rows } = await db.query(
    'SELECT id, qr_secret, is_open FROM class_sessions WHERE id=$1', [req.params.id]);
  const s = rows[0];
  if (!s || !s.is_open) return res.status(404).json({ error: 'Session not open' });

  const windowIdx = Math.floor(Date.now() / WINDOW_MS);
  res.json({
    token: tokenFor(s.id, s.qr_secret, windowIdx),
    expiresInMs: WINDOW_MS - (Date.now() % WINDOW_MS),
  });
});

// ---- student: submit scanned token + GPS -----------------------------------
app.post('/api/attendance/scan', async (req, res) => {
  if (req.user.role !== 'student') return res.sendStatus(403);
  const { token, lat, lng } = req.body;
  const [sessionId, windowStr, sig] = String(token || '').split('.');
  const windowIdx = Number(windowStr);
  if (!sessionId || !Number.isInteger(windowIdx) || !sig)
    return res.status(400).json({ error: 'Malformed token' });

  const { rows } = await db.query('SELECT * FROM class_sessions WHERE id=$1', [sessionId]);
  const s = rows[0];
  if (!s || !s.is_open) return res.status(404).json({ error: 'Session not open' });

  // Accept current window, plus the previous one as grace for network lag
  const nowIdx = Math.floor(Date.now() / WINDOW_MS);
  if (windowIdx !== nowIdx && windowIdx !== nowIdx - 1)
    return res.status(400).json({ error: 'QR expired, scan again' });

  const expected = tokenFor(s.id, s.qr_secret, windowIdx);
  const ok = expected.length === token.length &&
    crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(token));
  if (!ok) return res.status(400).json({ error: 'Invalid QR' });

  // Geofence
  if (typeof lat !== 'number' || typeof lng !== 'number')
    return res.status(400).json({ error: 'Location required' });
  const dist = haversineMeters(lat, lng, s.room_lat, s.room_lng);
  if (dist > s.radius_m)
    return res.status(403).json({ error: `Too far from classroom (${Math.round(dist)} m)` });

  // Must be enrolled in the course
  const enr = await db.query(
    'SELECT 1 FROM enrollments WHERE student_id=$1 AND course_id=$2',
    [req.user.id, s.course_id]);
  if (!enr.rowCount) return res.status(403).json({ error: 'Not enrolled' });

  await db.query(
    `INSERT INTO attendance_records (session_id, student_id, status, method, marked_at, lat, lng)
     VALUES ($1,$2,'PRESENT','QR',now(),$3,$4)
     ON CONFLICT (session_id, student_id)
     DO UPDATE SET status='PRESENT', method='QR', marked_at=now(), lat=$3, lng=$4`,
    [s.id, req.user.id, lat, lng]);

  io.to(`session:${s.id}`).emit('attendance', { studentId: req.user.id, status: 'PRESENT', method: 'QR' });
  res.json({ status: 'PRESENT' });
});

// ---- teacher: manual override ----------------------------------------------
app.put('/api/sessions/:id/attendance/:studentId', async (req, res) => {
  if (req.user.role !== 'teacher') return res.sendStatus(403);
  const { status } = req.body; // PRESENT | ABSENT | LATE | EXCUSED
  await db.query(
    `INSERT INTO attendance_records (session_id, student_id, status, method, marked_at, marked_by)
     VALUES ($1,$2,$3,'MANUAL_OVERRIDE',now(),$4)
     ON CONFLICT (session_id, student_id)
     DO UPDATE SET status=$3, method='MANUAL_OVERRIDE', marked_at=now(), marked_by=$4`,
    [req.params.id, req.params.studentId, status, req.user.id]);
  io.to(`session:${req.params.id}`).emit('attendance',
    { studentId: Number(req.params.studentId), status, method: 'MANUAL_OVERRIDE' });
  res.json({ ok: true });
});

// ---- teacher: full roster for a session ------------------------------------
app.get('/api/sessions/:id/roster', async (req, res) => {
  if (req.user.role !== 'teacher') return res.sendStatus(403);
  const { rows } = await db.query(
    `SELECT st.id, st.roll_no, st.name,
            COALESCE(a.status::text, 'ABSENT') AS status,
            a.method::text AS method
       FROM class_sessions cs
       JOIN enrollments e  ON e.course_id = cs.course_id
       JOIN students st    ON st.id = e.student_id
  LEFT JOIN attendance_records a ON a.session_id = cs.id AND a.student_id = st.id
      WHERE cs.id = $1
      ORDER BY st.roll_no`, [req.params.id]);
  res.json(rows);
});

server.listen(3000, () => console.log('API on :3000'));
