-- College attendance system schema (PostgreSQL)

CREATE TABLE students (
  id          SERIAL PRIMARY KEY,
  roll_no     TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  email       TEXT UNIQUE NOT NULL
);

CREATE TABLE courses (
  id          SERIAL PRIMARY KEY,
  code        TEXT UNIQUE NOT NULL,
  title       TEXT NOT NULL,
  teacher_id  INT NOT NULL
);

CREATE TABLE enrollments (
  student_id  INT REFERENCES students(id) ON DELETE CASCADE,
  course_id   INT REFERENCES courses(id) ON DELETE CASCADE,
  PRIMARY KEY (student_id, course_id)
);

-- One row per held class. qr_secret signs the rotating QR tokens.
CREATE TABLE class_sessions (
  id           SERIAL PRIMARY KEY,
  course_id    INT NOT NULL REFERENCES courses(id),
  starts_at    TIMESTAMPTZ NOT NULL,
  ends_at      TIMESTAMPTZ NOT NULL,
  room_lat     DOUBLE PRECISION NOT NULL,
  room_lng     DOUBLE PRECISION NOT NULL,
  radius_m     INT NOT NULL DEFAULT 50,
  qr_secret    TEXT NOT NULL,
  is_open      BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TYPE attendance_status AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');
CREATE TYPE checkin_method    AS ENUM ('QR', 'MANUAL_OVERRIDE');

CREATE TABLE attendance_records (
  id            SERIAL PRIMARY KEY,
  session_id    INT NOT NULL REFERENCES class_sessions(id) ON DELETE CASCADE,
  student_id    INT NOT NULL REFERENCES students(id),
  status        attendance_status NOT NULL DEFAULT 'ABSENT',
  method        checkin_method,                 -- NULL until marked
  marked_at     TIMESTAMPTZ,
  marked_by     INT,                            -- teacher id for manual overrides
  lat           DOUBLE PRECISION,               -- student's reported position (QR only)
  lng           DOUBLE PRECISION,
  UNIQUE (session_id, student_id)
);

CREATE TABLE leave_requests (
  id          SERIAL PRIMARY KEY,
  student_id  INT NOT NULL REFERENCES students(id),
  from_date   DATE NOT NULL,
  to_date     DATE NOT NULL,
  reason      TEXT,
  status      TEXT NOT NULL DEFAULT 'PENDING'   -- PENDING / APPROVED / REJECTED
);

CREATE INDEX idx_att_student ON attendance_records(student_id);
CREATE INDEX idx_att_session ON attendance_records(session_id);
